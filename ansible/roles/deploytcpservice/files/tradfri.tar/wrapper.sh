#!/bin/bash

flask $@
